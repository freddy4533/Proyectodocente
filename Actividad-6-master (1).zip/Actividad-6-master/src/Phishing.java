import java.io.*;
import java.util.*;

public class Phishing {
    private static final Map<String, Integer> terminosDePhishing = new HashMap<String, Integer>() {{
        put("Paypal", 3);
        put("Banco", 2);
        put("Contrasenha", 3);
        put("Cuenta", 2);
        put("Verificar", 1);
        put("Actualizar", 1);
        put("Seguridad", 1);
        put("Informacion personal", 3);
        put("Tarjeta de credito", 3);
        put("Datos bancarios", 3);
        put("Correo electronico", 3);
        put("Urgente", 2);
        put("Ebay", 3);
        put("Amazon", 2);
        put("Alertas", 1);
        put("Office 365: cambie sus datos de inmediato", 3);
        put("Factura", 1);
        put("Oferta", 2);
        put("Accion requerida", 3);
        put("Ha ganado", 3);
        put("Advertencia", 2);
        put("Amenaza", 2);
        put("Compra", 1);
        put("Trabajo", 3);
        put("Haga clic en este enlace", 3);
        put("Gratis", 2);
        put("Empieza ahora", 1);
        put("Tiempo limitado", 3);
        put("Numero de telefono", 3);
        put("Transferencia", 3);        
            
    }};

    public static void main(String[] args) {
        String rutaArchivo = "D:\\JAVA\\Actividad6Poo/datos.txt";
        detectarTerminosDePhishing(rutaArchivo);
    }

    private static void detectarTerminosDePhishing(String rutaArchivo) {
        try {
            File archivo = new File(rutaArchivo);
            Scanner escaner = new Scanner(archivo);

            Map<String, Integer> ocurrenciasTerminos = new HashMap<>();
            int puntosTotales = 0;

            while (escaner.hasNextLine()) {
                String linea = escaner.nextLine();
                for (String termino : terminosDePhishing.keySet()) {
                    if (linea.toLowerCase().contains(termino.toLowerCase())) {
                        ocurrenciasTerminos.put(termino, ocurrenciasTerminos.getOrDefault(termino, 0) + 1);
                        puntosTotales += terminosDePhishing.get(termino);
                    }
                }
            }

            for (String termino : ocurrenciasTerminos.keySet()) {
                System.out.println("Palabra o frase: " + termino + ", Numero de ocurrencias: " + ocurrenciasTerminos.get(termino) + ", Total de puntos: " + ocurrenciasTerminos.get(termino) * terminosDePhishing.get(termino));
            }

            System.out.println("\nTotal de puntos: " + puntosTotales);

            escaner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Archivo no encontrado.");
            e.printStackTrace();
        }
    }
}






